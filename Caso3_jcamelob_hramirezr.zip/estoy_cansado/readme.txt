El orden de los parametros en el archivo de config es:

n_emisores
n_servidores_entrega
n_filtros
bufferCapacity
entregaCapacity
totalItems
